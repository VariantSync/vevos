// A new file
#ifdef C
printf("Has been created!");
#endif
