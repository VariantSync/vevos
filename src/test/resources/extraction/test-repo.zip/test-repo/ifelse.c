// A comment
#include <something>

#if A
line 5;
#else
line 7;
line 8;
#endif

last line;
