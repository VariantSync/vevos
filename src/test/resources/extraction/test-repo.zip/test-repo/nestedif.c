line 1;
#if A
line 3;
#if B
line 5;
#else
new line 7;
#endif
line 7;
#endif
line 9;
