// This is an unchanged file.

// It is unchanged, because it will not change over several commits, except for the one adding it.

// Example example
#ifdef A
  void test() {}
#endif
